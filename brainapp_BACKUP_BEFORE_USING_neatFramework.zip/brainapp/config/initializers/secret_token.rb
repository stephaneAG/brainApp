# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Brainapp::Application.config.secret_token = '62c5890b2e91986dda7652c01f35bbf417e8c18b665aed09360539435f81aa7393b63118f189e87a904f8ed42958bf43867da8b3f38cfaace5c212d4732da873'
